function getRandom(r){
    var n = Math.floor(Math.random()*r)+1;        
    return n;
}
