function Room(roomName, desc){
    this.roomName = roomName;
    this.desc = desc;
}
